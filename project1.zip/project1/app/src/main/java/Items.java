public class Items {
    public static final int Lettuce_Points=200;
    public static final int BigMac_Points=100;

}
