import android.widget.ImageButton;

public class Characters {
    private ImageButton trump;
}
